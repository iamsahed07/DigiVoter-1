module.exports = {
  mode: "jit",
  content: ["./src/**/**/*.{js,ts,jsx,tsx,html,mdx}", "./src/**/*.{js,ts,jsx,tsx,html,mdx}"],
  darkMode: "class",
  theme: {
    screens: { md: { max: "1050px" }, sm: { max: "550px" } },
    extend: {
      colors: {
        white: { A700: "#ffffff" },
        gray: { "300_05": "#ecdfdf05" },
        blue: { 50: "#edf3fd" },
        light_blue: { A700: "#007fff" },
        deep_orange: { 300: "#ff8153", "50_7f": "#f3e6e67f" },
        amber: { A100: "#ffea88" },
        black: { 900: "#00020b", "900_01": "#000000" },
        blue_gray: { 100: "#d9d9d9" },
        indigo: { 300: "#878bb6" },
        teal: { 300: "#4acab4" },
      },
      boxShadow: { xs: "12px 12px  24px 0px #00000019" },
      fontFamily: { archivo: "Archivo", archivoblack: "Archivo Black", arialblack: "Arial Black" },
      backgroundImage: { gradient: "linear-gradient(180deg, #0b3193,#00020b)" },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
