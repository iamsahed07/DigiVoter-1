import React from "react";

const sizes = {
  xs: "text-xl font-normal",
  s: "text-[22px] font-normal",
  md: "text-[32px] font-normal md:text-3xl sm:text-[28px]",
};

const Text = ({ children, className = "", as, size = "md", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-white-A700 font-archivoblack ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Text };
