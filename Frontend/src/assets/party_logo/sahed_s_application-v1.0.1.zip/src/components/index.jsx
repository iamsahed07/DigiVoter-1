import { Text } from "./Text";
import { Heading } from "./Heading";
import { Img } from "./Img";
export { Text, Heading, Img };
