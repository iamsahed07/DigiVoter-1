import React from "react";
import { Helmet } from "react-helmet";
import { Text, Heading, Img } from "../../components";
import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { MenuItem, Menu, Sidebar } from "react-pro-sidebar";

export default function DashboardPage() {
  return (
    <>
      <Helmet>
        <title>Sahed's Application</title>
        <meta name="description" content="Web site created using create-react-app" />
      </Helmet>
      <div className="h-[1117px] w-full bg-white-A700 relative">
        <div className="flex md:flex-col justify-center items-center w-full h-max left-0 bottom-0 right-0 top-0 m-auto absolute md:relative">
          <div className="flex self-end justify-between items-end w-[29%] md:w-full mb-[122px] gap-5 p-[13px] md:p-5 z-[1] bg-gray-300_05 backdrop-opacity-[0.5] blur-[4.00px]">
            <Heading size="md" as="h1" className="mt-[9px] ml-[37px] md:ml-0 !font-arialblack">
              LogOut
            </Heading>
            <Img src="images/img_vector.svg" alt="vector_one" className="h-[41px] mb-[5px] mr-[71px] md:mr-0" />
          </div>
          <div className="flex flex-col items-center md:self-stretch ml-[-38px] gap-[31px] p-[52px] md:p-5 md:ml-0 bg-blue-50 flex-1">
            <div className="flex md:flex-col justify-center items-center w-[96%] md:w-full gap-[33px]">
              <div className="md:self-stretch h-[374px] md:w-full flex-1 relative md:flex-none">
                <div className="flex flex-col items-end w-[98%] h-max gap-3 left-0 bottom-0 right-0 top-0 p-11 m-auto md:p-5 bg-white-A700 shadow-xs absolute rounded-[15px]">
                  <Heading as="h2" className="!text-light_blue-A700">
                    New Applications
                  </Heading>
                  <Heading as="h3" className="mr-[21px] md:mr-0 !text-light_blue-A700">
                    Pending Status
                  </Heading>
                  <Heading as="h4" className="mr-[73px] md:mr-0 !text-light_blue-A700">
                    Approved
                  </Heading>
                  <Heading as="h5" className="mb-[158px] mr-[81px] md:mr-0 !text-light_blue-A700">
                    Rejected
                  </Heading>
                </div>
                <div className="flex sm:flex-col items-start w-[93%] left-[0.00px] top-[0.00px] m-auto absolute sm:relative">
                  <CircularProgressbar
                    strokeWidth={1}
                    value={50}
                    styles={{ trail: {}, path: { strokeLinecap: "square" } }}
                    className="sm:self-stretch h-[357px] z-[1] flex-1"
                  />
                  <div className="flex flex-col items-start w-[37%] sm:w-full mt-12 ml-[-21px] sm:ml-0">
                    <div className="h-[19px] w-[34px] bg-amber-A100 rounded" />
                    <div className="h-[19px] w-[34px] mt-[15px] bg-indigo-300 rounded" />
                    <div className="h-[19px] w-[34px] mt-[15px] bg-teal-300 rounded" />
                    <div className="h-[19px] w-[34px] mt-[15px] bg-deep_orange-300 rounded" />
                    <Text size="s" as="p" className="mt-[21px] !text-black-900">
                      Application Tracker
                    </Text>
                    <div className="self-stretch h-px w-full bg-black-900_01" />
                    <Text size="xs" as="p" className="mt-[7px] !text-black-900">
                      New Applications : 172
                    </Text>
                  </div>
                </div>
                <CircularProgressbar
                  strokeWidth={1}
                  value={50}
                  styles={{ trail: {}, path: { strokeLinecap: "square" } }}
                  className="h-[357px] w-[61%] left-[0.00px] top-[0.00px] m-auto absolute"
                />
                <CircularProgressbar
                  strokeWidth={25}
                  value={18}
                  styles={{
                    trail: { stroke: "#ffea88" },
                    path: { strokeLinecap: "square", transformOrigin: "center", transform: "rotate(147deg)" },
                  }}
                  className="h-[357px] w-[61%] left-[0.00px] top-[0.00px] m-auto absolute"
                />
              </div>
              <Img
                src="images/img_rectangle_8.png"
                alt="image"
                className="w-[45%] md:w-full object-cover rounded-[15px]"
              />
            </div>
            <div className="flex w-[95%] md:w-full mb-[95px] p-[18px] bg-white-A700 shadow-xs rounded-[15px]">
              <div className="w-full mb-[37px] ml-4 md:ml-0">
                <div className="flex justify-between gap-5 flex-wrap">
                  <Text as="p" className="self-end !text-light_blue-A700 text-center">
                    Recent Activities
                  </Text>
                  <Text as="p" className="self-start !text-light_blue-A700 text-center">
                    Veiw All
                  </Text>
                </div>
                <div className="h-px mt-[3px] bg-black-900_01" />
                <div className="h-[59px] mt-[21px] bg-blue_gray-100" />
                <div className="h-[59px] mt-1 bg-blue_gray-100" />
                <div className="h-[59px] mt-1 bg-blue_gray-100" />
                <div className="h-[59px] mt-1 bg-blue_gray-100" />
                <div className="h-[59px] mt-1 bg-blue_gray-100" />
                <div className="h-[59px] mt-1 bg-blue_gray-100" />
              </div>
            </div>
          </div>
        </div>
        <div className="flex md:flex-col justify-center items-start w-full h-max left-0 bottom-0 right-0 top-0 m-auto absolute md:relative">
          <Sidebar
            width="477px !important"
            className="flex flex-col h-screen top-0 md:p-5 bg-gradient !sticky overflow-auto md:hidden"
          >
            <div className="flex flex-col self-stretch items-center mt-[27px]">
              <div className="flex sm:flex-col justify-between items-start w-[81%] md:w-full gap-5">
                <div className="flex justify-center w-[28%] sm:w-full bg-white-A700 rounded-[10px]">
                  <Img src="images/img_rectangle_18.png" alt="image_one" className="self-start w-[96%] object-cover" />
                </div>
                <div className="flex flex-col mt-[11px]">
                  <Heading size="md" as="h2" className="!font-arialblack">
                    MAKAUT - W.B.
                  </Heading>
                  <Heading size="s" as="h5" className="!font-arialblack">
                    HOSTEL ALLOCATION
                  </Heading>
                </div>
              </div>
              <Menu
                menuItemStyles={{
                  button: {
                    padding: "24px 24px 24px 50px",
                    backgroundColor: "#ecdfdf05",
                    backdropFilter: "opacity(0.5)",
                    filter: "blur(4.00px)",
                    color: "#ffffff",
                    fontWeight: 400,
                    fontSize: "32px",
                    [`&:hover, &.ps-active`]: {
                      backgroundColor: "#f3e6e67f !important",
                      boxShadow: "12px 12px  24px 0px #00000019",
                    },
                  },
                }}
                rootStyles={{ ["&>ul"]: { gap: "0.51px" } }}
                className="flex flex-col self-stretch w-full mt-[19px]"
              >
                <MenuItem>Dashboard</MenuItem>
                <MenuItem>Hostel</MenuItem>
                <MenuItem>Applications</MenuItem>
                <MenuItem>Reports</MenuItem>
              </Menu>
              <Heading size="md" as="h2" className="self-end mt-[505px] !font-arialblack">
                LogOut
              </Heading>
            </div>
          </Sidebar>
          <div className="self-end md:self-stretch h-[100px] ml-[-475px] md:p-5 md:ml-0 bg-light_blue-A700 flex-1" />
        </div>
        <div className="flex left-[0.00px] top-[21%] m-auto bg-gray-300_05 backdrop-opacity-[0.5] blur-[4.00px] absolute">
          <Text />
        </div>
      </div>
    </>
  );
}
